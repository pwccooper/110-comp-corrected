namespace project.Models
{

    public class Car
    {
        public int id { get; set; }

        public string make { get; set; }

        public string model { get; set; }

        public int year { get; set; }

        public string color { get; set; }

        public int hp { get; set; }

        public decimal rentPrice { get; set; }

        public string picture { get; set; }

        public int passengers { get; set; }

        public int gasMileage { get; set; }

        public int cargoSpace { get; set; }
    }


}