function saveCar() {

    var make = $("#txtMake").val();
    var model = $("#txtModel").val();
    var year = $("#txtYear").val();
    var description = $("#txtDescription").val();
    var color = $("#txtColor").val();
    var hp = $("#txtHP").val();
    var price = $("#txtrentPrice").val();
    var picture = $("#txtPicture").val();
    var gasMileage = $("#txtgasMileage").val();
    var passengers = $("#txtPassengers").val();
    var cargoSpace = $("#txtcargoSpace").val();

    var newCar = {
        make: make,
        model: model,
        year: year,
        description: description,
        color: color,
        hp: hp,
        rentPrice: price,
        picture: picture,
        gasMileage: gasMileage,
        passengers: passengers,
        cargoSpace: cargoSpace,
    }

    console.log(newCar);

    $.ajax({
        url: '/Catalog/CreateCar',
        type: 'POST',
        contentType: 'application/json; charset=utf-8',
        data: JSON.stringify(newCar),
        success: function (data) {
            console.log("Response from Server");
        },
        error: function (error) {
            console.log("Error on com");
        }
    });
}





function init() {
    console.log("it's working");

    $("#btnSave").click(saveCar);
}

window.onload = init;