function getRepFromServer() {


    $.ajax({
        url: '/Catalog/GetCatalog',
        type: 'GET',
        success: function (data) {
            console.log("Response from Server", data);
            displayCatalog(data);
        },
        error: function (error) {
            console.error("Error on com", error);
        }
    });
}



function displayRep(list) {
    console.log("init display")
    for (var i = 0; i < list.length; i++) {
        var Representative = list[i];
        console.log("hi")
        var repContainer = $("#repList");
        var repTemplate =
            `
        <div class="card mb-3 col-md-6">
        <div class="row no-gutters">
        <div class="col-md-4">

        </div>
            <div class="col-md-5>
            <div class="card-body">
            <h5 class="card-title">${Representative.firstName} ${Representative.lastName}</h5>
            <p class="card-text">${Representative.phoneNumber}</p>
            <button class="btn btn-primary float-right" onclick="rent(${Representative.id})">Choose Me</button>
            </p>
            </div>
            </div>
        </div>    
        </div>
        `;
        console.log("hi")
        repContainer.append(repTemplate);
    }
}

function init() {
    console.log("init create rep");


}

window.onload = init;