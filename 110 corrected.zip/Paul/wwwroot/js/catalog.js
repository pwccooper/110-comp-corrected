function getCatalogFromServer() {


    $.ajax({
        url: '/Catalog/GetCatalog',
        type: 'GET',
        success: function (data) {
            console.log("Response from Server", data);
            displayCatalog(data);
        },
        error: function (error) {
            console.error("Error on com", error);
        }
    });
}

function displayCatalog(list) {
    console.log("init display")
    for (var i = 0; i < list.length; i++) {
        var car = list[i];
        console.log("hi")
        var carContainer = $("#carList");
        var carTemplate =
            `
        <div class="card mb-3 col-md-6">
        <div class="row no-gutters">
        <div class="col-md-4">
         <img src="${car.picture}" class="card-img">
        </div>
            <div class="col-md-5>
            <div class="card-body">
            <h5 class="card-title">${car.make} ${car.model}</h5>
            <p class="card-text">${car.description}</p>
            <p class="card-text"><small class="text-muted">Cargo:${car.cargoSpace} HP:${car.hp}</small></p>
            <p class="card-text"><span class="price">$ ${car.price}</span>
            <button class="btn btn-primary float-right" onclick="rent(${car.id})">Rent Me</button>
            </p>
            </div>
            </div>
        </div>    
        </div>
        `;
        console.log("hi")
        carContainer.append(carTemplate);
    }
}

function init() {
    console.log("Initialize Catalog");

    getCatalogFromServer();
}


window.onload = init;