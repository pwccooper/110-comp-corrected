using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using project.Models;
using Microsoft.EntityFrameworkCore;
using _110_Project_1.Home;

namespace project.Controllers
{

    public class RepresentativeController : Controller
    {

        private DataContext Context;
        public RepresentativeController(DataContext context)
        {
            Context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetList()
        {
            return Ok();
        }

        public IActionResult Save([FromBody] Representative newRep)
        {

            Console.WriteLine("\n\n\n\n");
            Console.WriteLine(newRep.firstName, newRep.lastName, newRep.phoneNumber);
            Console.WriteLine("\n\n\n\n");
            return Ok();
        }
    }
}
