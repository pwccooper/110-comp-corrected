using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using _110_Project_1.Models;
using project.Models;

namespace project.Controllers
{

    public class CatalogController : Controller
    {

        private DataContext Context;

        public CatalogController(DataContext context)
        {
            Context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }



        public IActionResult GetCatalog()
        {
            Console.WriteLine("Requested GetCalog");

            List<Car> list = new List<Car>();

            list.Add(new Car()
            {
                id = 1,
                make = "A",
                model = "asd",
                year = 2009
            });


            return Json(list);

        }

        [HttpPost]

        public IActionResult CreateCar([FromBody] Car newCar)
        {
            Console.WriteLine("Getting to CreateCar", newCar.model);

            Context.Cars.Add(newCar);
            Context.SaveChanges();

            Console.WriteLine();
            Console.WriteLine("*Saved!*");
            Console.WriteLine();

            return Json(newCar);
        }
    }

};

