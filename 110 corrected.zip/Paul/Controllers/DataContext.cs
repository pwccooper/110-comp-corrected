using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using _110_Project_1.Home;

namespace project.Models
{


    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        public DbSet<Car> Cars { get; set; }

        public DbSet<Representative> Representative { get; set; }
    }
}